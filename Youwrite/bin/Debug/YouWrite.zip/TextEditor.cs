﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace YouWrite
{
    public partial class phrases : UserControl
    {
        public phrases()
        {
            InitializeComponent();
        }

        private void phrases_Load(object sender, EventArgs e)
        {
            
        }

        private void phrases_Click(object sender, EventArgs e)
        {
            
        }

        private void advancedTextEditor2_Load(object sender, EventArgs e)
        {

        }
    }
}
